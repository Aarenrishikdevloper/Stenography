from argparse import FileType
from cProfile import label
from cgitb import text
from fileinput import filename
from logging import root
from tkinter import *
from tkinter import filedialog
import tkinter as tk
import sys
from PIL import Image, ImageTk
import os
from numpy import save

#designate height and width of the app
root=Tk()

width = 780
height = 500
x = (root.winfo_screenwidth()//2)-(width//2)
y = (root.winfo_screenheight()//2)-(height//2)

root.title("Steganography")
root.geometry(f'{width}x{height}+{x}+{y}'.format(width, height, x, y))
root.resizable(False,False)
root.configure(bg="#000033")


#defining background image
bg=ImageTk.PhotoImage(Image.open("bg2.png"))
my_label = Label(root, image=bg)
my_label.pack()

#defining the commands in buttons
def showimage():
    print("")

def Hide():
    print("")

def show():
    print("")

def save():
    print("")
    


image_icon=PhotoImage(file="icon.png")
root.iconphoto(False,image_icon)


Label(root,text="STEGANOGRAPHY",bg="black",fg="white",font="arial 25 bold").place(x=40,y=20)


#first frame
frame1=Frame(root,bd=3,bg="black",width=340,height=280,relief=GROOVE)
frame1.place(x=40,y=80)

lbl=Label(frame1,bg="black")
lbl.place(x=40,y=10)



#second frame
frame2=Frame(root,bd=3,bg="white",width=340,height=280,relief=GROOVE)
frame2.place(x=380,y=80)

text1=Text(frame2,font="Robote 20",bg="white",fg="black",relief=GROOVE,wrap=WORD)
text1.place(x=0,y=0,width=320,height=295)

scrollbar1=Scrollbar(frame2)
scrollbar1.place(x=320,y=0,height=300)

scrollbar1.configure(command=text1.yview)
text1.configure(yscrollcommand=scrollbar1.set)

#third frame
frame3=Frame(root,bd=3,bg="black",width=330,height=100,relief=GROOVE)
frame3.place(x=40,y=370)

Button(frame3,text="open Image",width=10,height=2,font="arial 14",command=showimage).place(x=40,y=30)
Button(frame3,text="save Image",width=10,height=2,font="arial 14",command=save).place(x=200,y=30)
Label(frame3,text="Picture, Image, Photo File",bg="black",fg="yellow").place(x=40,y=5)

#fourth frame
frame4=Frame(root,bd=3,bg="black",width=330,height=100,relief=GROOVE)
frame4.place(x=380,y=370)

Button(frame4,text="Hide Data",width=10,height=2,font="arial 14",command=Hide).place(x=40,y=30)
Button(frame4,text="Show Data",width=10,height=2,font="arial 14",command=show).place(x=200,y=30)
Label(frame4,text="Picture, Image, Photo File",bg="black",fg="yellow").place(x=40,y=5)



root.mainloop()
